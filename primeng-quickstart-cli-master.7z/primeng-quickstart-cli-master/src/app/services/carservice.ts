import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Car } from '../domain/car';
import 'rxjs/add/operator/toPromise';
import "rxjs/rx";

@Injectable()
export class CarService {
    
    constructor(private http: Http) {}

    getCarsSmall() {
        return this.http.get('https://car-grid.firebaseio.com/data.json')
                    .toPromise()
                    .then(res => <Car[]> res.json())
                    .then(data => { return data; });

        // return this.http.get('https://car-grid.firebaseio.com/data.json')
        // .map(res =>{
        //     let data = <Car[]> res.json()
        //     return data;
        // }) 
    }
}